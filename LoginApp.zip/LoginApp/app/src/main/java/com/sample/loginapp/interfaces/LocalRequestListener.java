package com.sample.loginapp.interfaces;

import com.sample.loginapp.models.Users;

public interface LocalRequestListener {

    default void onSuccess(String response) {
        /**
         * default implementation
         */
    }

    default void onSuccess(Users users) {
        /**
         * default implementation
         */
    }

    void onError(Exception e);
}
