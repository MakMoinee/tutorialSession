package com.sample.loginapp.services;

import android.content.Context;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.sample.loginapp.interfaces.LocalRequestListener;
import com.sample.loginapp.models.Users;

public class ServerRequests {

    Context mContext;

    public ServerRequests(Context mContext) {
        this.mContext = mContext;
    }

    public void login(Users users, LocalRequestListener listener) {
        String requestBody = new Gson().toJson(users);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                listener.onSuccess(response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                listener.onError(new Exception(error.getMessage()));
            }
        }) {
            @Override
            public byte[] getBody() throws AuthFailureError {
                return requestBody.getBytes();
            }
        };
        RequestQueue queue = Volley.newRequestQueue(mContext);
        queue.add(stringRequest);
    }

}
