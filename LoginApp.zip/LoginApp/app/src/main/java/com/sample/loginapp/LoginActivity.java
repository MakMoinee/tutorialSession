package com.sample.loginapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.sample.loginapp.databinding.ActivityLoginBinding;
import com.sample.loginapp.interfaces.LocalRequestListener;
import com.sample.loginapp.models.Users;
import com.sample.loginapp.parser.UserJSONParser;
import com.sample.loginapp.services.ServerRequests;

public class LoginActivity extends AppCompatActivity {

    ActivityLoginBinding binding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        listeners();
    }

    private void listeners() {
        binding.btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = binding.editEmail.getText().toString();
                String pass = binding.editPassword.getText().toString();
                if (email.equals("") && pass.equals("")) {
                    Toast.makeText(LoginActivity.this, "Please Don't Leave Empty Fields", Toast.LENGTH_SHORT).show();
                } else {
                    Users users = new Users();
                    users.setEmail(email);
                    users.setPassword(pass);

                    new ServerRequests(LoginActivity.this).login(users, new LocalRequestListener() {
                        @Override
                        public void onSuccess(String response) {
                            Users validUser = UserJSONParser.parseUserResponse(response);
                            if (validUser != null) {
                                Toast.makeText(LoginActivity.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                            }else{
                                Toast.makeText(LoginActivity.this, "Wrong Username or Password", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onError(Exception e) {
                            Toast.makeText(LoginActivity.this, "Wrong Username or Password", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }
}
