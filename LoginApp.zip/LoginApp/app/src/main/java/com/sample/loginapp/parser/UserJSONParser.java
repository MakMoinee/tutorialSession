package com.sample.loginapp.parser;

import android.util.Log;

import com.sample.loginapp.models.Users;

import org.json.JSONException;
import org.json.JSONObject;

public class UserJSONParser {
    public static Users parseUserResponse(String response) {
        try {
            JSONObject object = new JSONObject(response);
            Users users = new Users();
            users.setEmail(object.getString("email"));
            users.setPassword(object.getString("password"));
            users.setUserID(object.getInt("userID"));
            return users;
        } catch (JSONException e) {
            Log.e("ERROR_PARSING_USER", e.getMessage());
            return null;
        }
    }
}
